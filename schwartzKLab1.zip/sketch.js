function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(40);
  //Ring
  noFill();
  ellipse(200,200,380);
  ellipse(200,200,350);
  
  //Shooting Star
  line(30,80,380,300);
  
  //Moon
  strokeCap(PROJECT);
  fill(180);
  circle(200,200,320);
  fill(170);
  circle(120,260,80);
  fill(165);
  circle(130,170,75);
  fill(160);
  circle(210,125,70);
  fill(155);
  circle(320,180,65);
  fill(150);
  circle(260,260,60);
  fill(145);
  circle(200,300,55);
  fill(140);
  circle(180,200,50);
  fill(135);
  circle(80,190,45);
  fill(130);
  circle(130,100,40);
  fill(125);
  circle(260,180,35);
  fill(120);
  circle(230,220,30);
  fill(115);
  circle(270,120,25);
  fill(110);
  circle(120,140,20);
  fill(105);
  circle(140,170,15);
  fill(100);
  circle(120,200,10);
  
  //Stars
  fill(255);
  circle(100,25,5);
  circle(80,15,5);
  circle(30,180,5);
  circle(30,25,5);
  circle(45,45,5);
  circle(200,35,5);
  circle(220,30,5);
  circle(300,25,5);
  circle(350,30,5);
  circle(30,300,5);
  circle(60,340,5);
  circle(320,380,5);
  circle(340,360,5);
  circle(300,335,5);
  circle(370,320,5);
  circle(180,370,5);
  circle(360,250,5);
  circle(35,200,5);
  circle(370,210,5);
  circle(350,120,5);
}