function setup() {
  createCanvas(400, 400);
  background(0);
}

let a = 0; // if counter
let b = 0; // else counter
let check = false; // mousepressed check

function mousePressed(){
  check = true;
}

function draw() {
  frameRate(60);
  noStroke();
  
  //mouse drawing 
  let x = mouseX;
  let y = mouseY;
  let x1 = pmouseX;
  let y1 = pmouseY;
  colorMode(RGB, 255);
  fill(0, 200, 0);
  circle(x1+5, y1+5, 20);
  fill(200,0,0);
  circle(pow(x,2)/100, pow(y,2)/100, 20);
  fill(0,0,200);
  circle(sqrt(x)*10, sqrt(y)*10, 20);
  
  
  //click canvas for firework
  if(check == true){
    background(0);
    if(a < 200){
    fill(80);
    circle(300-a/2, 400-a, 5)
    a++;
    }else if (b < 220){
      background(220-b*2);
      fill(220-b*2, 220-b*2, 0);
      circle(200,200,10);
      circle(235,176,10);
      circle(277,154,10);
      circle(270,144,10);
      circle(260,147,10);
      circle(165,180,10);
      circle(172,215,10);
      fill(220-b*1.75, 220-b*1.75, 0);
      circle(174,245,10);
      circle(245,263,10);
      circle(186,200,10);
      circle(220,134,10);
      circle(174,162,10);
      circle(210,175,10);
      fill(220-b*1.5, 220-b*1.5, 0);
      circle(255,180,10);
      circle(184,150,10);
      circle(235,235,10);
      circle(196,263,10);
      circle(274,172,10);
      circle(288,215,10);
      fill(220-b*1.25, 220-b*1.25, 0);
      circle(167,215,10);
      circle(200,235,10);
      circle(215,271,10);
      circle(222,186,10);
      circle(174,243,10);
      circle(217,215,10);
      fill(220-b, 220-b, 0);
      circle(240,230,10);
      circle(270,190,10);
      circle(243,210,10);
      circle(260,220,10);
      circle(176,250,10);
      circle(253,186,10);
      circle(188,226,10);
      circle(234,177,10);
      b++;
      }
  }
  
  
      
}