function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
  background(0,180,220);
  
  //Quad Balloon
  fill(200,200,0,0.8);
  quad(100,100,150,150,135,250,75,175);
  noFill();
  curve(0,0,135,250,200,300,400,400);
  
  //Shape Balloon
  fill(200,0,0,0.8)
  beginShape();
  vertex(300,100);
  vertex(250,150);
  vertex(280,250);
  vertex(350,175);
  vertex(300,100);
  endShape();
  noFill();
  curve(400,0,280,250,200,300,0,400);
  
  //Triangle Balloon
  fill(0,200,0,0.8);
  triangle(200,200,150,100,250,100);
  noFill();
  curve(200,0,200,200,200,300,0,400);
  
  //Extra Balloon 1
  fill(0,0,200,0.8);
  ellipse(150,125,70,120);
  noFill();
  curve(0,0,150,185,200,300,400,400);
  
  //Extra Balloon 2
  fill(200,0,200,0.8);
  ellipse(250,150,70,120);
  noFill();
  curve(0,0,250,210,200,300,400,400);
  
}

function draw() {
  
}
